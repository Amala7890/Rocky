/*
Copyright Siemens AG 2018
SPDX-License-Identifier: MIT
*/

module.exports.notification = require('./notification');
