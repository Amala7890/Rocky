/*
Copyright Siemens AG 2018
SPDX-License-Identifier: MIT
*/

import { AppPage } from './app.po';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('TODO');
  });
});
