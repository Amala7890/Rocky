/*
Copyright Siemens AG 2018
SPDX-License-Identifier: MIT
*/

export class UserInfo {
  id: string;
  name: string;
  email: string;
}
