/*
Copyright Siemens AG 2018
SPDX-License-Identifier: MIT
*/

export class Todo {
  _id?: string;
  title: string;
}
