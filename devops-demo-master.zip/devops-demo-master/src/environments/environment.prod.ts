export const environment = {
  production: true,
  mdsp: {
    xsrfTokenHeader: null,
    sessionCookie: null
  }
};
